.. include:: ../doc/sources/building-android-binary.rst
