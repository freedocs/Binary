.. include:: ../doc/sources/tutorial-server.rst

libevent-server.c
-----------------

.. literalinclude:: ../examples/libevent-server.c
